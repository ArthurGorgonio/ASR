char * getIp(char * host);

char * getPage(char * ss);